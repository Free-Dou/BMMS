var color_store = "";

function button_mouseenter(button_id)
{
	var x = document.getElementById(button_id);
	color_store = x.style.backgroundColor;
	x.style.color = "black";
	x.style.backgroundColor = "white";
}
function button_mouseleave(button_id)
{
	var x = document.getElementById(button_id);
	x.style.color = "white";
	// x.style.backgroundColor = "#0078D7";
	x.style.backgroundColor = color_store;
}
function button_mousedown(button_id)
{
	var x = document.getElementById(button_id);
	x.style.color = "black";
	x.style.backgroundColor = "#F7F7F7";
}
function button_mouseup(button_id)
{
	var x = document.getElementById(button_id);
	x.style.color = "black";
	x.style.backgroundColor = "white";
}

function button_mouseenter_footer(button_id)
{
	var x = document.getElementById(button_id);
	x.style.backgroundColor = "rgba(255,255,255,0.2)";
}
function button_mouseleave_footer(button_id)
{
	var x = document.getElementById(button_id);
	x.style.backgroundColor = "rgba(255,255,255,0.0)";
}
function button_mousedown_footer(button_id)
{
	var x = document.getElementById(button_id);
	x.style.backgroundColor = "rgba(255,255,255,0.1)";
}
function button_mouseup_footer(button_id)
{
	var x = document.getElementById(button_id);
	x.style.backgroundColor = "rgba(255,255,255,0.2)";
}
