function refreshme()
{
	parent.refresh_now_page_noresponse();
}
