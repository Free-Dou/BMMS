function confirm_click()
{

}

function myremove(index)
{
	
}

function cancle_click()
{
	setTimeout("hide_window()", 10);
}
