function confirm_click()
{
	// document.forms["login_form"].submit();
}

function cancle_click()
{
	setTimeout("hide_window()", 10);
}
