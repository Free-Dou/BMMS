
parent.window.document.location.href = "index.html";